@extends('layouts.admin')
@section('css')

@endsection('css')
@section('script')
    <script src="/js/sweetalert.min.js"></script>
    @include('sweet::alert')
@endsection('script')
@section('navbar')

@endsection('navbar')
@section('sidebar')

@endsection('sidebar')
@section('content')

    @if(auth()->user()->role=='admin')
        <div class="row">
            <div class="col-md-3">

                <div class="card text-center">
                    <div class="card-body">
                        <div class="icon-block icon-block-xl m-b-20 bg-info-gradient icon-block-floating">
                            <i class="fa fa-user-o"></i>
                        </div>
                        <h3 class="font-weight-800 primary-font">{{\App\Models\User::all()->count()}}</h3>
                        <p>مجموع کاربران</p>
                    </div>
                </div>

            </div>
            <div class="col-md-3">

                <div class="card text-center">
                    <div class="card-body">
                        <div class="icon-block icon-block-xl m-b-20 bg-info-gradient icon-block-floating">
                            <i class="fa fa-user-o"></i>
                        </div>
                        <h3 class="font-weight-800 primary-font">{{\App\Models\User::all()->where('level_id',1)->count()}}</h3>
                        <p>تعداد مهمان</p>
                    </div>
                </div>

            </div>
        </div>
    @else
        <div class="row">
            <div class="col-md-3">

                <div class="card text-center">
                    <div class="card-body">
                        <div class="icon-block icon-block-xl m-b-20 bg-info-gradient icon-block-floating">
                            <i class="fa fa-user-o"></i>
                        </div>
                        <?php
                        $createDate = auth()->user()->created_at;
                        $now = \Carbon\Carbon::now();

                        $diff = $createDate->diffInDays($now);
                        ?>
                        <h3 class="font-weight-800 primary-font">{{$diff}}</h3>
                        <p>گذشته از شروع فعالیت</p>
                    </div>
                </div>

            </div>
        </div>

    @endif
@endsection('content')


