<?php

namespace App\Http\Controllers;

use App\Models\Learn;
use App\Models\Level;
use Illuminate\Http\Request;

class LearnController extends Controller
{
    /**
     * ImageController constructor.
     */
    public function __construct()
    {
        $this->fileController = new FileController();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rows = Learn::with('level')->orderBy('created_at', 'desc')->paginate(30);
        return view('panel.learn.index', ['rows' => $rows]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $levels = Level::all();

        return view('panel.learn.create', ['levels' => $levels]);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $row = Learn::create([
            'title' => $request->title,
            'body' => $request->body,
            'level_id' => $request->level_id,
            'user_id' => auth()->user()->id,
        ]);
        $this->fileController->getUploadImage($request, $row, 'learn');
        alert()->success('محصول جدید با موفقیت افزوده شد', 'عملیات موفق');

        return redirect('learns');
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $row = Learn::where('id', $id)->first();
        $levels = Level::all();
        return view('panel.learn.edit', ['row' => $row, 'levels' => $levels]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $row = Learn::where('id', $id)->first();
        $row->update([
            'title' => $request->title,
            'body' => $request->body,
            'level_id' => $request->level_id,
        ]);
        $this->fileController->getUploadImage($request, $row, 'product');
        alert()->success('محصول  با موفقیت ویرایش شد', 'عملیات موفق');

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $row = Learn::where('id', $id)->first();
        $row->delete();
    }

    public function files($id)
    {
        $files = Learn::where('id', $id)->with('files')->first();
        return view('panel.learn.files', ['id' => $id, 'model' => 'App\Models\Learn', 'files' => $files]);
    }

    public function learns_level($levelId)
    {
        if (auth()->user()->level_id < $levelId) {
            alert()->error('شما دسترسی ندارید.', 'ورود ناموفق');
            return redirect('panel');
        }
        $rows = Learn::with('level')
            ->where('level_id', $levelId)
            ->orderBy('created_at', 'desc')->paginate(30);
        return view('panel.learn.level', ['rows' => $rows]);
    }

    public function show($id)
    {
        $row = Learn::where('id', $id)
            ->with('files')
            ->with('user')
            ->first();
        return view('panel.learn.show', ['row' => $row]);

    }
}
